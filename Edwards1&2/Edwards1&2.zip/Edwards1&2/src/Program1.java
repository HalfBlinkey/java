/**
 * 
 */

/**
 * @author hambricedwards
 * @#23180290000
 */
public class Program1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	      //print messgaes
        System.out.println("My name is Hambric");
        System.out.println("The default type for an floating point number is a double");
        System.out.println("Java int types are stored in 32 bits");
        System.out.println("float price = 1.29; This is incorrect in Java. Fix it double price = 1.29;");
        System.out.println("Type Long can store extremely large integers");
        System.out.println("Java class names begin with an Uppercase case character");

	}

}
